# GCP ↔ WSL Hermes 双向通信桥梁

## GCP 侧（已配置）

| 项目 | 值 |
|:--|:--|
| 公网 IP | `35.212.210.211` |
| Webhook 端口 | `8645` |
| 平台密钥 | `gcp-wsl-bridge-secret-2026` |
| 订阅名称 | `wsl-to-gcp` |
| 订阅密钥 | `huEaDGl1dCMLPFMcWcS4PK32qTZRZZzkyUi3yy8CJYo` |

## WSL → GCP

WSL Hermes 向 GCP webhook 发送 POST：

```
POST http://35.212.210.211:8645/webhooks/wsl-to-gcp
Content-Type: application/json
X-Hub-Signature-256: sha256=<HMAC-SHA256(secret, body)>
```

Body: `{"message": "要发送的内容"}`

验证 webhook 是否活着：
```bash
curl http://35.212.210.211:8645/health
# → {"status": "ok", "platform": "webhook"}
```

## GCP → WSL

需要 WSL 侧开 SSH 反向隧道才能从 GCP 主动连 WSL：

```bash
# 在 WSL 上执行：
ssh -R 8646:localhost:8645 root@35.212.210.211
```

之后 GCP 可以向 `localhost:8646` POST，隧道会转发到 WSL 的 webhook。

## 现有配置

GCP config.yaml 中的 webhook 配置：
```yaml
platforms:
  webhook:
    enabled: true
    extra:
      host: 0.0.0.0
      port: 8645
      secret: gcp-wsl-bridge-secret-2026
```
