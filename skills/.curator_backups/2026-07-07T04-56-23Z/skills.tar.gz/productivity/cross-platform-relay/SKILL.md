---
name: cross-platform-relay
description: Operate Hermes as a bidirectional message relay between two messaging platforms (e.g., WeChat ↔ Telegram) with platform-specific behavior modes, roleplay tagging, and proactive cron check-ins.
version: 1.0.0
author: Hermes Agent
tags: [relay, gateway, wechat, telegram, family, messaging, cross-platform]
---

# Cross-Platform Message Relay

Use Hermes as a **pure relay** between two messaging platforms — forward messages between them verbatim without auto-responding to relay content. Supports per-platform behavior modes (work vs. play), roleplay identity tagging, and scheduled proactive check-ins.

## Setup

### Platform Requirements
- Both platforms must be configured and connected via `hermes gateway setup`
- Verify both show as connected: `grep "connected" ~/.hermes/logs/gateway.log`
- Channel directory must be populated: `cat ~/.hermes/channel_directory.json`

### Verify Relay Capability
```bash
# Test send to each platform (use -q for faster delivery)
hermes send -q --to weixin "test message"
hermes send -q --to telegram "test message"
```

## Relay Mechanics

### Core Rule
When user A says "tell user B [message]", relay the message to the target platform. **Do not** auto-respond to the relay target or add your own commentary. **Do not** reply to the sender confirming delivery.

### Message Tagging
Prefix relayed messages with a clear direction label so recipients know who the message is from:

| Direction | Label |
|-----------|-------|
| Platform A → Platform B | **【A传话】** natural message 😄 |
| Platform B → Platform A | **【B传话】** natural message 😄 |

Example labels: 【妈妈传话】, 【爸爸传话】, 【A传话】, 【B传话】

### Paraphrasing & Flair
Messages do **not** need to be forwarded word-for-word. The user expects natural paraphrasing:

- **Rephrase naturally** — "跟妈妈说爸爸回来了" → "妈妈，爸爸说他回来了"
- **Add emojis** to match the tone (😄❤️🍦🎯 etc.)
- **Add flair/戏** — playful embellishment is welcome
- **Do NOT add commentary** — don't explain the relay, don't add meta-commentary
- **Keep it natural** — relay should read like a normal chat message

### Relay Flow
1. User A sends "tell user B [message]" on Platform A
2. Agent relays naturally with potential paraphrasing: `hermes send -q --to platformB "【A传话】natural message 🎯"`
3. User B replies on Platform B
4. Agent forwards reply back: `hermes send -q --to platformA "【B传话】[reply]"`
5. Rinse and repeat — pure relay, no auto-reply

## Platform-Specific Behavior Modes

Each platform can have a different personality/behavior mode:

| Mode | Behavior | Use Case |
|------|----------|----------|
| **Work** | Professional, task-focused, minimal banter | Productivity, coding, admin |
| **Play** | Playful, affectionate, jokes, roleplay | Family chat, entertainment |

When a message comes in **that does not involve relay** (e.g., casual chat on the play platform), respond in that platform's mode naturally. Only relay when the user explicitly asks to pass a message to the other side.

## Proactive Check-In (Cron)

For regular proactive messages to a platform (e.g., daily greetings to family), create a cron job:

```bash
# Example: 3x daily at 9am/2pm/8pm CST (UTC+8 → 1/6/12 UTC)
hermes cron create \
  --name "family-checkin" \
  --schedule "0 1,6,12 * * *" \
  --prompt "Send a playful greeting to [platform/recipient]" \
  --deliver local
```

Job prompt should be self-contained: specify platform, recipient ID, tone/style, and to use `hermes send -q` for delivery.

## Security & Approvals

For relay-only traffic (repetitive `hermes send` commands between trusted family channels), disable command approval prompts to avoid friction:

```bash
hermes config set approvals.mode off     # Skip all approval prompts
hermes config set approvals.mode smart   # AI-judged, low-risk auto-approved
```

## Performance

- Use `hermes send -q` (quiet mode) instead of default — returns in ~3s instead of timing out at 15-20s
- Approvals mode `off` eliminates all confirmation dialogs for relay messages
- For maximum speed, disable both approvals and verbose output

## Pitfalls

- **Do NOT auto-reply to relay targets.** When user A says "tell user B X", relay to B. Do not also reply to A about having forwarded it — that pollutes the relay flow.
- **Paraphrase naturally, but don't add commentary.** Rephrase the message in natural language with appropriate emojis. Do not add meta-commentary like "he asked me to tell you" or explanatory framing.
- **Relay mode vs casual mode are separate.** Casual chat on the play platform is fine to respond to naturally. Only switch to relay mode when the user says "tell [other person]..."
- **Message tagging is critical.** Without labels, recipients can't tell whether a message is from the agent or relayed from the other person.
- **iLink Bot accounts** (WeChat iLink) typically cannot join ordinary WeChat groups — group relay may not work regardless of config. This is a Tencent-side limitation.
- **`hermes send` may timeout** waiting for delivery confirmation. The message is usually still delivered — check gateway logs or use `-q` to avoid the hang.
