---
name: sing-box-vps
description: Set up and manage sing-box proxy servers on VPS using popular community scripts (yonggekkk/sing-box-yg, etc.). Supports Vless-reality-vision, Vmess-ws/Argo, Hysteria-2, Tuic-v5, Anytls protocols.
tags: [sing-box, proxy, vps, vpn, yonggekkk, reality, hysteria, tuic, troubleshooting]
---

# Sing-box VPS Proxy Setup

Set up sing-box proxy protocols on a VPS using the popular **yonggekkk/sing-box-yg** ("甬哥精装桶") script. 8847⭐ on GitHub.

## Quick Install

```bash
bash <(curl -Ls https://raw.githubusercontent.com/yonggekkk/sing-box-yg/main/sb.sh)
```

After install, management shortcut: `sb`

## Supported Protocols

| Protocol | Transport | Notes |
|----------|-----------|-------|
| Vless-reality-vision | Reality | No cert needed, no domain needed |
| Vmess-ws(tls) | WebSocket + TLS | Works with Argo CDN |
| Hysteria-2 | QUIC-based | UDP-friendly, fast |
| Tuic-v5 | QUIC-based | Low latency |
| Anytls | TLS-based | Latest addition |

## Features

- **No domain required** — self-signed certs work out of the box
- **ACME certs** — can switch to real domain certs via acme-yg
- **Argo tunnels** — supports both fixed and temporary Argo tunnels (can coexist)
- **Psiphon VPN** — integrates 30-country Psiphon VPN as WARP alternative
- **Pure IPv4 / IPv6 / dual-stack** support
- **amd64 + arm64** architecture support
- **Alpine / Ubuntu / Debian / CentOS** support
- **Local subscription generation** — no third-party subscription converters

## Management Commands

After install, run `sb` to enter the management menu:
- Add/remove protocols
- Switch cert type (self-signed ↔ ACME)
- Configure Argo tunnels
- View subscription links
- Uninstall

## Subscription Output

The script generates locally:
- **Sing-box** client config (SFA/SFI/SFW)
- **Clash/Mihomo** compatible config
- **Share links** for copying to client apps at `/etc/s-box/vl_reality.txt`, `/etc/s-box/vm_ws_tls.txt`, `/etc/s-box/hy2.txt`, `/etc/s-box/tuic5.txt`, `/etc/s-box/an.txt`
- **Clash subscription** at `/etc/s-box/clmi.yaml`
- **Combined subscription text** at `/etc/s-box/jhsub.txt`

## Serv00/Hostuno Edition

For free Serv00 / paid Hostuno accounts:

```bash
bash <(curl -Ls https://raw.githubusercontent.com/yonggekkk/sing-box-yg/main/serv00.sh)
```

Supports vless-reality, vmess-ws(argo), hysteria2 on Serv00 with argo tunnel.

## Health Check & Auto-Restart

After setup, set up a daily health check that verifies sing-box is running and auto-restarts on failure.

### Manual diagnostic commands

```bash
# Check process
pgrep -f "sing-box run"
# Check listening ports
ss -tlnp | grep sing-box
# Check config
/etc/s-box/sing-box check -c /etc/s-box/sb.json
# Check service
systemctl is-active sing-box.service
# Service logs
journalctl -u sing-box.service --no-pager -n 20
```

### Auto-restart script

Store at `~/.hermes/scripts/sing-box-check.sh` and set up as a daily cron job. The script exits silently (no output) when everything is normal — the user only receives a message when something actually went wrong and was fixed.

```bash
#! /bin/bash
# Checks: process running, ports listening, config valid
# On failure: restarts sing-box service
# On success: reports uptime, ports, memory usage
SERVICE="sing-box.service"
PID=$(pgrep -f "sing-box run" | head -1)
PORTS=$(ss -tlnp | grep sing-box | awk '{print $4}' | awk -F: '{print $NF}')
CONFIG_OK=$(/etc/s-box/sing-box check -c /etc/s-box/sb.json && echo true || echo false)
```

Cron job setup:
```python
cronjob(action='create', name='sing-box-health-check', schedule='0 8 * * *',
    script='/root/.hermes/scripts/sing-box-check.sh', no_agent=True, deliver='origin')
```

See `scripts/sing-box-check.sh` for the full implementation.

## Troubleshooting

### Config validation

```bash
/etc/s-box/sing-box check -c /etc/s-box/sb.json
```

Returns `FATAL ...` with the specific line/field that's wrong, or exits silently on success.

### Service status & logs

```bash
systemctl status sing-box.service
journalctl -u sing-box.service --no-pager -n 20
```

If the service shows `activating (auto-restart)` with `(Result: exit-code)`, check the journal for the fatal error. A high restart counter (e.g. "restart counter is at 56") indicates a persistent config problem that systemd retries aggressively and burns CPU.

### Restart loop escalation

If sing-box keeps restarting, **stop the service first** to stop the loop before fixing:

```bash
systemctl stop sing-box.service
# fix config, then:
systemctl start sing-box.service
```

### Tuic version field removed (sing-box ≥1.13.x)

Sing-box 1.13+ removed the `"version"` field from tuic inbound configuration. If `sb.json` contains:

```json
{
    "type": "tuic",
    "version": 4,
    "tag": "tuic5-sb",
    ...
}
```

sing-box will fail with:
```
FATAL decode config: inbounds[3].version: json: unknown field "version"
```

**Fix:** Remove the `"version": 4,` line from the tuic inbound block. Sing-box auto-detects tuic version in newer releases.

```bash
sed -i '/"version": 4,/d' /etc/s-box/sb.json
/etc/s-box/sing-box check -c /etc/s-box/sb.json  # verify
systemctl restart sing-box.service
```

See `references/tuic-version-field.md` for detailed error transcript.

## Server Prep & Cleanup

When setting up sing-box on a VPS that also runs Hermes Agent, strip unnecessary services to keep memory under 1GB. Typical junk found on cloud VPS images:

| Service | Reason to Remove |
|---------|-----------------|
| **BT Panel (宝塔面板)** | Heavy web panel with Nginx/Nodejs; not needed |
| **Docker** | If no containers run, just wastes ~30MB + containerd |
| **Snapd** | Eats 10%+ CPU even when idle |
| **Google Cloud Ops Agent** | Monitoring suite (~80MB); only needed if using GCP monitoring |
| **site_total** | Spawned by BT Panel |

### Cleanup checklist

1. **BT Panel**: `systemctl stop bt.service && rm -rf /www`
2. **Docker**: `apt-get purge -y docker-ce docker-ce-cli containerd.io && rm -rf /var/lib/docker`
3. **Snapd**: `systemctl stop snapd.service snapd.socket && systemctl mask snapd.service --now && apt-get purge -y snapd && rm -rf /snap /var/snap /var/lib/snapd`
4. **Google Cloud Ops Agent**: `systemctl mask google-cloud-ops-agent.service --now && dpkg --purge --force-remove-reinstreq google-cloud-ops-agent && rm -rf /opt/google-cloud-ops-agent`
5. Run `apt-get autoremove --purge -y` to clean orphaned deps
6. Run `dpkg --configure -a` to fix any interrupted dpkg state after bulk removals
7. `systemctl daemon-reload` after removing service files

## Kernel Optimization for Low-Memory (≤1GB) VPS

After stripping unnecessary services on a 1GB VPS that also runs Hermes Agent, apply these sysctl tweaks to reduce memory pressure:

```bash
# /etc/sysctl.d/99-sing-box-optimize.conf
vm.vfs_cache_pressure = 200        # Reclaim cache faster under memory pressure
vm.dirty_ratio = 10                # Reduce dirty page ceiling
vm.dirty_background_ratio = 5      # Start writeback earlier
net.ipv4.tcp_fastopen = 3          # Enable TFO for both client & server
net.ipv4.tcp_slow_start_after_idle = 0  # Keep connections warm
```

Apply:
```bash
sysctl -p /etc/sysctl.d/99-sing-box-optimize.conf
```

### Performance impact

| Metric | Before | After | Why |
|--------|--------|-------|-----|
| Available memory | ~286MB | ~440MB | Bloat stripped + cache tuned |
| Disk usage (29GB) | 8.5G | 5.3G | 3.2GB freed from panels/caches |
| Service restarts | 59× (sing-box loop) | stable | Config fixed + loop broken |

## References

- `references/yonggekkk-sing-box-yg.md` — Full repo reference, file structure, video tutorials
- `references/tuic-version-field.md` — Tuic version compatibility error transcript (sing-box 1.13.x)

## Pitfalls

- **Must run as root** — the script checks EUID and exits if not root
- **Not for OpenVZ/LXC** — some virtualization types unsupported
- **Serv00 scripts risk account ban** — free accounts may be terminated
- **Firewall** — ensure ports are open (script handles most defaults)
- **Systemd requirement** — the service registers as a systemd unit
- **GCP cloud firewall ≠ VM firewall** — On GCP, even if `ufw` allows all ports and sing-box is listening, traffic won't reach the VM unless GCP cloud firewall rules also allow the ports. Add rules via `gcloud compute firewall-rules create ... --target-tags http-server`. See the `gcp-operations` skill for details.
- **Tuic version field removed in sing-box 1.13+** — see troubleshooting section above
- **Restart loop** — sing-box auto-restarting 50+ times will burn CPU; stop service before fixing config
- **Config backup exists** — `/etc/s-box/sb.json.bak` may contain a working config without the version field if tuic was the only problem
- **Service respawning** — `systemctl stop + disable` is not always enough. Services like `google-cloud-ops-agent` can respawn because the systemd unit is referenced by other units or alias. Use `systemctl mask <service> --now` to symlink the unit to `/dev/null`, preventing any activation path.
- **dpkg interruptions** — After bulk package removal, `dpkg --configure -a` may fail with `'ldconfig' not found in PATH'`. Fix: `export PATH=$PATH:/usr/sbin:/sbin` before running dpkg/apt commands.
- **Low-memory (≤1GB) kernel tuning** — After stripping bloat, also apply sysctl tweaks (see kernel optimization section)
