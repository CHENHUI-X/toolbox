---
name: linux-server-audit
description: Systematically audit a Linux server to identify resource hogs, unnecessary services, cache bloat, and apply low-memory kernel optimizations. Covers process/service inventory, disk analysis, package cleanup, and performance tuning.
tags: [audit, optimization, performance, troubleshooting, cleanup, linux, devops]
related_skills: [sing-box-vps]
---

# Linux Server Audit & Optimization

Systematic approach to auditing what's on a Linux server, identifying what's consuming resources, cleaning up unnecessary services/packages, and optimizing for specific workloads.

## When to Use

- User says "server feels slow" or "why is it so laggy"
- User asks "look at what's installed" or "audit the server"
- Before deploying a new service on an existing server (clean slate)
- After inheriting a pre-configured VPS with unknown installed software

## Audit Workflow

### 1. Quick Triage — what's eating resources

```bash
# Processes by memory (biggest offenders first)
ps aux --sort=-%mem | head -20

# Processes by CPU
ps aux --sort=-%cpu | head -20

# Memory overview
free -h

# Disk usage
df -h /
```

### 2. Service Inventory

```bash
# Running services
systemctl list-units --type=service --state=running

# All enabled services (start at boot)
systemctl list-unit-files --type=service --state=enabled

# Check for Docker containers (if Docker is installed)
docker ps -a --format "table {{.Names}}\t{{.Image}}\t{{.Status}}"
```

### 3. Disk Deep-Dive

```bash
# Per-top-level-directory (quick)
du -sh /* 2>/dev/null | sort -rh | head -20

# Common bloat locations
du -sh /var/log /var/cache/apt /root/.cache /root/.npm /root/.local /snap /opt /www 2>/dev/null
```

### 4. Network & Ports

```bash
# Listening ports (excluding localhost-only)
ss -tlnp | grep -v "127.0.0.1"
```

## Common Bloat to Remove

| Service | Symptoms | Removal |
|---------|----------|---------|
| **BT Panel (宝塔面板)** | `/www/server/panel/` process, port 23884 | `rm -rf /www` |
| **Docker** | `dockerd` process but `docker ps` shows no containers | `apt-get purge -y docker-ce docker-ce-cli containerd.io` |
| **Snapd** | 10%+ CPU even idle, process always running | `apt-get purge -y snapd && rm -rf /snap /var/snap /var/lib/snapd` |
| **Google Cloud Ops Agent** | fluent-bit + otelopscol processes | `systemctl mask <service> --now && dpkg --purge google-cloud-ops-agent` |
| **Google Guest/OSConfig Agent** | GCP default agents | Disable if not using GCP features |

**IMPORTANT — The Mask Pattern:** Some services (notably `google-cloud-ops-agent`) respawn even after `systemctl stop && disable` because systemd unit aliases or dependencies pull them back. Use `systemctl mask <service> --now` to symlink the unit to `/dev/null` — this blocks every activation path including dependency-driven starts.

### Cache Cleanup Targets

| Cache | Typical Size | Command |
|-------|-------------|---------|
| APT | 100-250MB | `apt-get clean && apt-get autoclean` |
| Journald logs | 200-500MB | `journalctl --vacuum-time=3d` |
| npm cache | 100-200MB | `rm -rf /root/.npm/_cacache` |
| pip cache | 50-200MB | `pip cache purge && rm -rf /root/.cache/pip` |
| uv cache | 100-300MB | `uv cache clean` |
| Old log files | varies | `find /var/log -name "*.gz" -o -name "*.old" -o -name "*.1" ... -delete` |
| apt archives | 100-200MB | `rm -rf /var/cache/apt/archives/*.deb` |

**⚠️ CRITICAL PITFALL — Do NOT delete `~/.local/share/uv/python/`**

If any venv on this server was created via `uv` (e.g. Hermes Agent's venv), its Python interpreter is a symlink into `~/.local/share/uv/python/cpython-3.XX-.../bin/python3.XX`. Running `rm -rf ~/.local/share/uv/` or `rm -rf ~/.local/share/uv/python` will **break every venv that uses uv-managed Python** — they become dangling symlinks with `No such file or directory`.

**Safe uv cleanup:** Only clean `~/.cache/uv/` (the download cache), which contains compiled wheels and won't break venvs:
```bash
uv cache clean           # this cleans ~/.cache/uv  — SAFE
rm -rf ~/.cache/uv       # equivalent — SAFE
```

**UNSAFE — will break venvs:**
```bash
rm -rf ~/.local/share/uv/python    # DESTROYS PYTHON BINARIES — venvs break
rm -rf ~/.local/share/uv           # DESTROYS EVERYTHING — venvs break
```

**If you already broke a venv this way**, recreate it with the system Python:
```bash
apt-get install -y python3-venv
cd /path/to/project
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -e .
```

Disable the OOM-style crash reporter too if present:
```bash
systemctl disable --now apport.service  # crash reporting
systemctl disable --now pollinate.service  # entropy gathering
```

### dpkg State Recovery

After bulk package removal, check for interrupted dpkg state:

```bash
export PATH=$PATH:/usr/sbin:/sbin
dpkg --configure -a
```

On GCP VMs, `/usr/sbin` and `/sbin` are often missing from PATH in non-interactive shells, causing spurious `'ldconfig' not found in PATH or not executable` errors during dpkg operations.

## Low-Memory Kernel Tuning (≤1GB RAM)

After stripping bloat, apply sysctl tweaks:

```bash
cat > /etc/sysctl.d/99-server-optimize.conf << 'EOF'
vm.vfs_cache_pressure = 200
vm.dirty_ratio = 10
vm.dirty_background_ratio = 5
net.ipv4.tcp_fastopen = 3
net.ipv4.tcp_slow_start_after_idle = 0
EOF
sysctl -p /etc/sysctl.d/99-server-optimize.conf
```

| Parameter | Default | Optimized | Effect |
|-----------|---------|-----------|--------|
| `vfs_cache_pressure` | 100 | 200 | Reclaim inode/dentry cache faster under memory pressure |
| `dirty_ratio` | 20 | 10 | Less dirty page accumulation before flush |
| `dirty_background_ratio` | 10 | 5 | Start write-back earlier |
| `tcp_fastopen` | 1 | 3 | Enable TFO for both directions |
| `tcp_slow_start_after_idle` | 1 | 0 | Don't reset cwnd after idle |

## Verification

After cleanup, verify:

```bash
# Process check — should see only what you need
ps aux --sort=-%mem | head -5

# No unwanted services
ps aux | grep -cE "snapd|docker|containerd|BT-Panel|BT-Task|fluent-bit|otelopscol"

# Resource check
free -h
df -h /
systemctl is-active hermes-gateway.service sing-box.service  # or your target services
```

## Post-Optimization: Auto-Maintenance Cron Jobs

After cleaning and tuning, offer to set up auto-maintenance scripts that run daily.

Store maintenance scripts in `~/.hermes/scripts/` and use the `cronjob` tool with `no_agent=True` to run them on schedule — the script's stdout is delivered verbatim to the user.

### Hermes auto-update script (`scripts/hermes-update.sh`)
- Schedule: daily 09:00
- Does `git fetch + pull` in the Hermes repo — **does NOT touch venv or gateway** (user handles that)
- State file at `/tmp/hermes-update-state` tracks daily success/failure to support retry schedules
- Silent exit on success/no-update — only outputs when there's actually a new version or an error

### Sing-box health check script (`scripts/sing-box-check.sh`)
- Schedule: daily (any time)
- Checks process + ports + config validity
- On failure: auto-restarts the sing-box service and reports the recovery
- **Silent exit when everything is normal** — no output = no message to the user
- Only speaks when there's a problem or an action was taken

### Key pattern: `no_agent=True` silent-on-success scripts

When writing a cron script delivered via `no_agent=True`:

```
exit 0 with no stdout     → user gets nothing (silent success)  ✅
exit 0 with stdout         → message delivered to user           ✅
exit non-zero              → error notification sent to user     🚨
```

Use this to avoid spamming the user with "everything is fine" reports. Only emit stdout when something actually happened (new update available, service restarted, error encountered).

For daily-one-cron with retry support, use a state file:
```bash
STATE_FILE="/tmp/<jobname>-state"
TODAY=$(date +%Y-%m-%d)

# If already succeeded today, exit silently
if [ -f "$STATE_FILE" ]; then
    DATE=$(head -1 "$STATE_FILE")
    RESULT=$(tail -1 "$STATE_FILE")
    if [ "$DATE" = "$TODAY" ] && [ "$RESULT" = "success" ]; then
        exit 0
    fi
fi

# ... do the work ...

echo "$TODAY" > "$STATE_FILE"
echo "success" >> "$STATE_FILE"  # or "failed"
```

This supports multiple cron schedules (e.g., 09:00 + 10-18 hourly retries) without duplicate work or spam.

## Pitfalls

- **`patch` tool won't write to `/etc/`** — the `patch` tool refuses system paths. Use `sed -i` via terminal instead for config files under `/etc/`.
- **dpkg + PATH on GCP** — `dpkg --configure -a` fails with `'ldconfig' not found` unless PATH includes `/usr/sbin:/sbin`. Always export PATH first when running dpkg/apt in non-interactive Hermes terminal sessions.
- **Swap files in `/www/`** — BT Panel creates a 1GB swap file at `/www/swap`. After removing `/www`, run `swapoff /www/swap && rm -f /www/swap` to reclaim the space. The `swapoff` binary is in `/sbin/` (PATH issue again).
- **Service respawning** — `systemctl stop` + `disable` is not sufficient for services with alias/dependency chains. Always `mask` services you want permanently gone.
- **`apt-mark hold` can block removal** — If you previously ran `apt-mark hold <package>`, purge will fail with `Held packages were changed and -y was used without --allow-change-held-packages`. Run `apt-mark unhold <package>` first, or add `--allow-change-held-packages`.
- **`kill` vs `pkill -9`** — Processes in D state (uninterruptible sleep) resist SIGTERM. Use `pkill -9 -f <pattern>` for stubborn processes.

## References

- `references/server-audit-example.md` — Full session transcript with exact commands, error messages, and before/after metrics from a 1GB GCP VM audit.
