---
name: hermes-cross-instance-communication
description: "Set up and manage communication between two Hermes Agent instances (e.g. GCP + WSL) using gcloud IAP tunnels and webhooks — no public ports required."
version: 1.1.0
author: Agent
tags: [hermes, webhook, iap, tunnel, cross-instance, wsl, gcp]
---

# Hermes Cross-Instance Communication

Guide for connecting two Hermes Agent instances (e.g. one on GCP connected to Telegram, one on WSL connected to WeChat) via gcloud IAP tunnels and Hermes webhooks.

## Architecture

```
┌──────────────────┐         IAP Tunnels         ┌──────────────────┐
│  WSL Hermes       │ ◄──────────────────────►  │  GCP Hermes       │
│  (WeChat)         │  :8645 fwd → GCP Webhook  │  (Telegram)       │
│                   │  :8644 rev ← WSL Webhook  │                   │
└──────────────────┘                            └──────────────────┘
```

Key design decisions:
- **No public ports** — all traffic goes through Google's internal network via IAP
- **Two tunnels**: forward (WSL→GCP) and reverse (GCP→WSL) for bidirectional communication
- **HMAC-SHA256 signed** webhooks for authentication between instances

## Tunnel Setup

### Prerequisites
- `gcloud` CLI installed and authenticated on both sides
- IAP (Identity-Aware Proxy) enabled on the GCP compute instance
- Appropriate IAM permissions (`roles/iap.tunnelResourceAccessor`)

### WSL → GCP — Forward Tunnel
Makes GCP's webhook reachable at WSL's localhost:8645:
```bash
gcloud compute ssh <instance-name> \
  --tunnel-through-iap \
  --zone <zone> \
  -- -L 8645:localhost:8645 -N
```

### GCP → WSL — Reverse Tunnel
Makes WSL's webhook reachable at GCP's localhost:8644:
```bash
gcloud compute ssh <instance-name> \
  --tunnel-through-iap \
  --zone <zone> \
  -- -R 8644:localhost:8644 -N
```

## Webhook Setup

### On the receiving side (each instance)
Create a webhook subscription:
```bash
hermes webhook subscribe <name> \
  --events task \
  --prompt "任务来源：{message}" \
  --deliver origin
```
This creates a subscription in `~/.hermes/webhook_subscriptions.json` with an auto-generated HMAC secret.

### Sending a signed webhook POST (Python)

The webhook adapter accepts **multiple signature header formats**. Pick one:

**Option A — Generic `X-Webhook-Signature` (recommended for custom scripts):**
```python
import json, hmac, hashlib, urllib.request

payload = {"event_type": "task", "message": "your instruction here"}
body = json.dumps(payload).encode()
sig = hmac.new(b"<secret>", body, hashlib.sha256).hexdigest()

req = urllib.request.Request("http://localhost:8644/webhooks/<route-name>",
    data=body,
    headers={
        "Content-Type": "application/json",
        "X-Webhook-Signature": sig  # plain hex HMAC-SHA256
    })
resp = urllib.request.urlopen(req, timeout=15)
# → 202 {"status": "accepted", ...}
```

**Option B — GitHub `X-Hub-Signature-256` (used by `hermes webhook test` CLI):**
```python
sig = "sha256=" + hmac.new(b"<secret>", body, hashlib.sha256).hexdigest()
# Header: "X-Hub-Signature-256": sig
```

**Option C — Plain token (GitLab style `X-Gitlab-Token`):**
Useful for simple callers (cURL, webhook services) where HMAC computation is impractical:
```python
# Header: "X-Gitlab-Token": "<plain-secret>"
```

All formats authenticate the same way — the adapter detects which header is present and validates accordingly.

## Pitfalls & Learnings

### 1. Prompt Template Variable Names
The webhook prompt template uses **flat JSON field names** from your POST body — NOT nested under `payload.`.

✅ Correct (if POST body is `{"message": "..."}`):
```
prompt: "任务来源：{message}"
```

❌ Wrong:
```
prompt: "任务来源：{payload.message}"
```
This renders as the literal string `{payload.message}` because there's no `payload` key at the top level of your JSON body.

If you want nested template access, structure your POST body accordingly:
```json
{"payload": {"message": "..."}}
```

### 2. Secret Resets on Subscription Recreate
Each `hermes webhook subscribe` call generates a **new random HMAC secret**. If you delete and recreate a subscription, the secret changes. Both sides must coordinate on the current secret.

### 3. `hermes webhook test` Returns "ignored"
The `hermes webhook test <name>` command sends event type `test` (via `X-GitHub-Event: test` header). If your route only accepts `task` events, you'll get:
```json
{"status": "ignored", "event": "test"}
```
**This is normal** — it means authentication (HMAC signing) passed. The route just filtered the event. Use `--payload` to override:
```bash
hermes webhook test <name> --payload '{"event_type": "task", "message": "hello"}'
```

### 4. Delivery Configuration
- `--deliver origin` — response goes back to the sender via the webhook
- `--deliver weixin` — WSL processes the task and the webhook delivery system automatically pushes the agent's **final response** to WeChat. The agent itself does NOT need messaging tools (send_message, etc.) — just complete the task and let delivery happen.
- `--deliver telegram` — for GCP Hermes with Telegram configured

**Important:** With `--deliver weixin`, the task you send to the agent should be phrased as "process this and reply with X" — the reply *becomes* the delivered message. Don't ask the agent to "send a WeChat message" — it won't have the tools to do so, and it doesn't need them.

### 5. Hermes Internal Cron vs System Cron
Hermes internal cron jobs stop when the gateway is down. For infrastructure-critical monitoring (tunnel health checks), use **system crontab** (`/etc/cron.d/`) instead.

### 6. GCP Ephemeral IP Changes on Reboot

GCP instances use ephemeral public IPs by default. If the instance is stopped/started or rebooted, the IP **may change** — and the change is silent.

This breaks:
- **Tunnel connections** (the `-L`/`-R` in your IAP tunnel command references hostnames, but any external client config pointing to the old IP breaks)
- **Proxy node URLs** in Clash/v2ray configs stored with the old IP

**Check current IP from GCP:**
```bash
curl -s -H "Metadata-Flavor: Google" \
  http://metadata.google.internal/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip
```

**Mitigation:** Set up a cron-based IP change monitor (every 30 min, silent when unchanged, Telegram notification on change). See the `gcp-operations` skill for a complete script pattern.

**Long-term fix:** Promote to a static IP:
```bash
gcloud compute addresses create my-static-ip --region <region>
# Then attach to instance
```

### 7. GCP Firewall Blocks Proxy Ports Despite ufw Being Open
If Sing-box shows all ports listening locally but Clash/v2ray reports **timeouts from the outside**:

1. **Check GCP instance network tags:**
   ```bash
   curl -s -H "Metadata-Flavor: Google" \
     http://metadata.google.internal/computeMetadata/v1/instance/tags
   # Typical: ["http-server","https-server"] → only ports 80,443 allowed
   ```

2. **Test external port reachability from the server itself:**
   ```bash
   curl -s --connect-timeout 5 -o /dev/null -w "%{http_code} (%{time_total}s)\n" \
     http://<PUBLIC_IP>:<PORT>/
   # Timeout = GCP firewall blocking
   ```

3. **Fix — add GCP firewall rules:**
   ```bash
   gcloud compute firewall-rules create allow-proxy-nodes \
     --allow tcp:33741,tcp:2096,tcp:29624,udp:65083,udp:53900 \
     --source-ranges 0.0.0.0/0 \
     --target-tags http-server
   ```
   Or add them via GCP Console → VPC Network → Firewall.

**Note:** ufw rules on the VM and GCP cloud firewall rules are independent. Traffic must pass BOTH layers. If the GCP firewall blocks it, the packet never reaches the VM's ufw.
